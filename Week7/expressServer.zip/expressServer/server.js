// {
//   "name": "expressserver", // to make package : npm init (-y to answer yes to everything)
//   "version": "1.0.0",
//   "description": "",
//   "main": "server.js",
//   "scripts": {
//     "test": "echo \"Error: no test specified\" && exit 1",
//     "start": "nodemon server.js" // change "node server.js" to "nodemon server.js"
//   },
//   "author": "Lauren",
//   "license": "ISC",
//   "dependencies": {
//     "express": "^4.18.2"
//   },
//   "devDependencies": { // npm i -D nodemon : to add nodemon to devDependencies 
//     "nodemon": "^2.0.20"
//   }
// }


console.log('hello lauren')

const express = require('express')
const {products} = require('./modules/data.js')

const app = express();

app.listen(8000, () =>{
    console.log('running on 8000')
})

// app.get('/api/products',(req, res)=>{
    // const products = [
    //     {id:1, name:'iphone',price:1800},
    //     {id:2, name:'ipad',price:800},
    //     {id:3, name:'iwatch',price:650}
    // ]
//     res.json(products)
// })

app.use('/', express.static(__dirname + '/public'))

app.get('/api/products',(req, res)=>{
    res.json(products);
})

app.get('/about',(req, res)=>{
    res.sendFile(__dirname + '/public/about.html')
})

// app.get('/yaniv/zivuch', (req, res)=>{
//     res.json({message:"ok"})
// })