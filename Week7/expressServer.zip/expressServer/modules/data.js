    const products = [
        {id:1, name:'iphone',price:1800},
        {id:2, name:'ipad',price:800},
        {id:3, name:'iwatch',price:650}
    ]
    module.exports = {
        products
    }