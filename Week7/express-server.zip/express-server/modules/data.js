const products = [
  {id:1,name:'iPhone',price:1800},
  {id:2,name:'iPad',price:800},
  {id:3,name:'iWatch',price:650}
];

module.exports = {
  products
}
